<?php
header('Location: demo/phpThumb.demo.demo1.php');
?>
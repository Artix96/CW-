<?php plogger_get_header(); ?>

		<div id="thumbnail-container">

			<div id="error-404">
				<h2><?php echo plog_tr('404 - Not Found')?></h2>
				<p><?php echo plog_tr('We are sorry, but the page that you are looking for does not exist. You might try using the <strong>Search</strong> feature to locate the image or album you are looking for.')?></p>
			</div><!-- /error-404 -->

		</div><!-- /thumbnail-container -->

<?php plogger_get_footer(); ?>
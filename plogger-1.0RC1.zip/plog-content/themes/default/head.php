<?php echo plogger_generate_seo_meta_tags();?>
	<link rel="stylesheet" type="text/css" href="<?php echo THEME_URL ?>gallery.css" />
	<script type="text/javascript" src="<?php echo THEME_URL ?>dynamics.js"></script>
